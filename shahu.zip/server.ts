import express from "express";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Increase request size limit for base64 images
app.use(express.json({ limit: "10mb" }));

// Initialize GoogleGenAI SDK on the server side securely
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// API endpoint for analyzing road infrastructure reports with Gemini
app.post("/api/analyze-image", async (req, res) => {
  try {
    const { image, mimeType } = req.body;

    if (!image) {
      return res.status(400).json({ error: "Missing image data" });
    }

    // Strip data URL prefixes if present
    const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
    const cleanMimeType = mimeType || "image/jpeg";

    if (!process.env.GEMINI_API_KEY) {
      // Return a structured dummy analysis if API key is missing (fallback) so the app remains interactive in any environment
      return res.json({
        type: "pothole",
        severity: "medium",
        description: "[Demo Mode] A severe pavement crack of approximately 30cm depth. Location suggests recurring water logging damage."
      });
    }

    // Call Gemini with multimodal image input under structured JSON constraints
    const prompt = `Analyze this road infrastructure reporting image. Identify if it shows:
- A pothole (or damaged pavement, cracking, deep road crater)
- A streetlight (or broken post, damaged fixture, dark roadway at night)
- Another road infrastructure issue (other)

Categorize the issue type, estimate the severity based on public hazard, and write a 1-2 sentence description detailing the visual damage for utility repairs.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: cleanMimeType,
            data: base64Data,
          },
        },
        prompt,
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: {
              type: Type.STRING,
              enum: ["pothole", "streetlight", "other"],
              description: "Category of utility infrastructure damage"
            },
            severity: {
              type: Type.STRING,
              enum: ["low", "medium", "high", "critical"],
              description: "Public danger severity level"
            },
            description: {
              type: Type.STRING,
              description: "A short, structured description of the observed issue"
            },
          },
          required: ["type", "severity", "description"],
        },
      },
    });

    const parsedResponseStr = response.text || "{}";
    const analysis = JSON.parse(parsedResponseStr.trim());
    return res.json(analysis);

  } catch (error: any) {
    console.error("Gemini Image Analysis Error:", error);
    return res.status(500).json({
      error: "AI analysis failed",
      details: error.message || String(error),
      fallback: {
        type: "pothole",
        severity: "medium",
        description: "Roadway deformation reported. Analysis timed out but ticket registered."
      }
    });
  }
});

async function startServer() {
  // Configure Vite middleware for dev or serve static bundle in production
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Bind to port 3000 and 0.0.0.0
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server executing at http://0.0.0.0:${PORT}`);
  });
}

startServer();
