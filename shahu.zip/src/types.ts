export type IssueType = "pothole" | "streetlight" | "other";
export type SeverityLevel = "low" | "medium" | "high" | "critical";
export type TicketStatus = "submitted" | "in_review" | "scheduled" | "in_progress" | "resolved";

export interface Report {
  id?: string; // Firestore document ID
  ticketId: string; // 8-character unique ticket ID
  imageUrl: string; // Base64 data of image
  type: IssueType;
  severity: SeverityLevel;
  description: string;
  latitude: number;
  longitude: number;
  status: TicketStatus;
  createdAt: string; // ISO date string or timestamp convertible
  updatedAt?: string;
  reportedBy: string; // User ID
  reporterName: string;
  reporterEmail: string;
  adminNotes?: string;
}

export interface UserStats {
  submitted: number;
  resolved: number;
  inProgress: number;
}
