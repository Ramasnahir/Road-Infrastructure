import React, { useRef, useState, useEffect } from "react";
import { Camera, RefreshCw, Upload, Image as ImageIcon, CheckCircle, AlertTriangle } from "lucide-react";

interface CameraCaptureProps {
  onPhotoSource: (base64Image: string) => void;
}

export default function CameraCapture({ onPhotoSource }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [hasCamera, setHasCamera] = useState<boolean>(false);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);

  // Check for camera media devices
  useEffect(() => {
    async function checkCamera() {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const devices = await navigator.mediaDevices.enumerateDevices();
          const videoDevices = devices.filter(device => device.kind === "videoinput");
          setHasCamera(videoDevices.length > 0);
        } catch {
          setHasCamera(false);
        }
      }
    }
    checkCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (streamRef.current) {
        stopCamera();
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
    } catch (err: any) {
      console.error("Camera access failed", err);
      setCameraError(
        "Could not verify camera stream. Please upload an image directly if camera access is restricted in this window's sandbox."
      );
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas");
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        
        // Compress image to comfortably fit well under the Firestore size limit of 1MB
        // 0.7 quality produces very clean outputs around 50KB to 100KB
        const base64 = canvas.toDataURL("image/jpeg", 0.7);
        onPhotoSource(base64);
        stopCamera();
      }
    }
  };

  // Drag and drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      alert("Please upload a valid image file");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        // Double check base64 format and compress if needed by drawing to virtual canvas
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;
          
          // Max dimension to keep payload light
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 600;
          if (width > MAX_WIDTH || height > MAX_HEIGHT) {
            if (width > height) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            } else {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx?.drawImage(img, 0, 0, width, height);
          const compressedBase64 = canvas.toDataURL("image/jpeg", 0.7);
          onPhotoSource(compressedBase64);
        };
        img.src = result;
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <div id="camera-capture-container" className="w-full">
      {cameraActive ? (
        <div id="live-camera-view" className="relative bg-slate-950 rounded-2xl overflow-hidden aspect-video border border-slate-800 shadow-xl">
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            playsInline
            muted
          />
          <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-slate-950/80 to-transparent flex justify-center gap-3">
            <button
              id="btn-take-photo"
              onClick={capturePhoto}
              type="button"
              className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-medium rounded-full flex items-center gap-2 shadow-lg hover:shadow-red-500/20 active:scale-95 transition-all text-sm"
            >
              <div className="w-3 h-3 bg-white rounded-full animate-ping" />
              Capture Photo
            </button>
            <button
              id="btn-cancel-camera"
              onClick={stopCamera}
              type="button"
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-full text-sm transition-all"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div
            id="upload-dropzone"
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`cursor-pointer border-2 border-dashed rounded-3xl p-8 flex flex-col items-center justify-center text-center transition-all min-h-[220px] ${
              dragActive
                ? "border-emerald-500 bg-emerald-500/5 text-emerald-800"
                : "border-slate-200 hover:border-slate-300 bg-slate-50 text-slate-600"
            }`}
          >
            <div className="p-3 bg-white rounded-2xl shadow-sm border border-slate-100 mb-4 text-emerald-600">
              <Upload className="w-6 h-6 animate-bounce" />
            </div>
            
            <p className="text-base font-semibold text-slate-800 mb-1">
              Upload an image or start camera
            </p>
            <p className="text-xs text-slate-400 max-w-[280px] mb-5">
              Drag and drop an image file here, or click to find file
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <label className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-xl text-sm shadow-md shadow-emerald-600/10 active:scale-95 transition-all cursor-pointer">
                Choose Image
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileInput}
                  className="hidden"
                />
              </label>

              {hasCamera && (
                <button
                  id="btn-start-camera"
                  onClick={startCamera}
                  type="button"
                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-900 border border-slate-700 text-white font-medium rounded-xl text-sm shadow-sm active:scale-95 transition-all flex items-center gap-2"
                >
                  <Camera className="w-4 h-4" />
                  Use Live Camera
                </button>
              )}
            </div>
          </div>

          {!hasCamera && (
            <div className="p-3.5 bg-amber-50 border border-amber-200/60 rounded-xl flex items-start gap-2.5 text-xs text-amber-800">
              <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold">Direct Camera Inactive:</span> Hardware camera stream was not requested or is blocked inside an iframe sandbox. Uploading files directly is pre-configured and completely operational.
              </div>
            </div>
          )}

          {cameraError && (
            <div className="p-3.5 bg-red-50 border border-red-100 rounded-xl text-xs text-red-600">
              {cameraError}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
