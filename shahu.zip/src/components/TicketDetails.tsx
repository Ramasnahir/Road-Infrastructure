import React, { useState } from "react";
import { Report, TicketStatus } from "../types";
import { 
  MapPin, Clock, ShieldAlert, CheckCircle2, Circle, 
  Wrench, FileText, User, Calendar, ExternalLink, RefreshCw 
} from "lucide-react";

interface TicketDetailsProps {
  report: Report;
  onUpdateStatus?: (status: TicketStatus, adminNotes?: string) => Promise<void>;
}

export default function TicketDetails({ report, onUpdateStatus }: TicketDetailsProps) {
  const [updating, setUpdating] = useState<boolean>(false);
  const [showSimPanel, setShowSimPanel] = useState<boolean>(false);
  const [adminNotes, setAdminNotes] = useState<string>(report.adminNotes || "");

  const statusWorkflow: { value: TicketStatus; label: string; desc: string }[] = [
    { value: "submitted", label: "Submitted", desc: "Citizen complaint safely logged on Namma-Raste network" },
    { value: "in_review", label: "Under Review", desc: "Local engineering team assessing damage metrics" },
    { value: "scheduled", label: "Scheduled", desc: "Repair dispatch ticket assigned to regional crew" },
    { value: "in_progress", label: "In Progress", desc: "Crew dispatched; active physical repairs on site" },
    { value: "resolved", label: "Resolved", desc: "Task completed. Pavement cleared to standard" }
  ];

  const getStatusBadge = (status: TicketStatus) => {
    const configs: Record<TicketStatus, { bg: string; text: string; label: string }> = {
      submitted: { bg: "bg-blue-100 text-blue-800 border-2 border-slate-900", text: "text-blue-800", label: "Logged" },
      in_review: { bg: "bg-purple-100 text-purple-800 border-2 border-slate-900", text: "text-purple-800", label: "Reviewing" },
      scheduled: { bg: "bg-amber-100 text-amber-800 border-2 border-slate-900", text: "text-amber-800", label: "Scheduled" },
      in_progress: { bg: "bg-cyan-100 text-cyan-800 border-2 border-slate-900", text: "text-cyan-800", label: "Fixing" },
      resolved: { bg: "bg-orange-100 text-orange-850 border-2 border-slate-900", text: "text-orange-800", label: "Resolved" }
    };
    return configs[status] || configs.submitted;
  };

  const getSeverityBadge = (level: string) => {
    const configs: Record<string, { bg: string; text: string }> = {
      low: { bg: "bg-slate-100 text-slate-800 border-2 border-slate-900", text: "Low Urgency" },
      medium: { bg: "bg-amber-100 text-amber-800 border-2 border-slate-900", text: "Medium Threat" },
      high: { bg: "bg-orange-100 text-orange-800 border-2 border-slate-900", text: "High Threat" },
      critical: { bg: "bg-rose-100 text-rose-800 border-2 border-slate-900", text: "Critical Hazard" }
    };
    return configs[level] || configs.medium;
  };

  const currentStatusIndex = statusWorkflow.findIndex(s => s.value === report.status);

  const handleStateTransition = async (nextStatus: TicketStatus) => {
    if (!onUpdateStatus) return;
    setUpdating(true);
    try {
      await onUpdateStatus(nextStatus, adminNotes);
    } finally {
      setUpdating(false);
    }
  };

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${report.latitude},${report.longitude}`;

  return (
    <div id={`ticket-card-${report.ticketId}`} className="bg-white border-2 border-slate-900 shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] rounded-2xl overflow-hidden divide-y-2 divide-slate-900">
      {/* Ticket Header Banner */}
      <div className="p-6 bg-slate-950 text-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-41:">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="font-mono text-[10px] uppercase tracking-widest text-orange-400 font-bold">
                Ticket Reference
              </span>
              <span className="px-2 py-0.5 bg-slate-800 text-slate-300 font-mono text-[10px] rounded font-medium border border-slate-700">
                #{report.id?.substring(0, 5) || "local"}
              </span>
            </div>
            <h2 className="text-3xl font-black font-display tracking-tight text-white uppercase">
              {report.ticketId}
            </h2>
          </div>

          <div className="flex items-center gap-2.5 self-start sm:self-center">
            <span className={`px-3 py-1 text-xs font-bold font-mono uppercase tracking-wider rounded-lg ${getStatusBadge(report.status).bg}`}>
              {getStatusBadge(report.status).label}
            </span>
            <span className={`px-2.5 py-1 text-xs font-bold font-mono uppercase tracking-wider rounded-lg ${getSeverityBadge(report.severity).bg}`}>
              {getSeverityBadge(report.severity).text}
            </span>
          </div>
        </div>
      </div>

      {/* Main Stats Card Split */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
        
        {/* Left Side: Photo & Reporter Details */}
        <div className="p-6 md:col-span-5 space-y-6">
          <div>
            <h3 className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-2 font-mono">
              Reported Visual Assets
            </h3>
            <div className="relative rounded-xl overflow-hidden aspect-square border-2 border-slate-900 bg-slate-900 group shadow-md shadow-slate-100">
              <img 
                src={report.imageUrl} 
                alt="Infrastructure incident reported"
                className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 px-3 py-1 bg-slate-950/80 backdrop-blur-md rounded border border-slate-800 text-[10px] font-bold text-white uppercase tracking-wider font-mono">
                {report.type}
              </div>
            </div>
          </div>

          {/* Location Dashboard details */}
          <div className="bg-slate-50 border-2 border-slate-900 rounded-xl p-4.5 space-y-3.5 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
            <div className="flex items-start justify-between">
              <div className="flex gap-2.5">
                <MapPin className="w-4.5 h-4.5 text-orange-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-850 font-display">Geotagged Coordinates</h4>
                  <div className="text-xs font-mono text-slate-500 mt-0.5">
                    {report.latitude.toFixed(5)}° N, {report.longitude.toFixed(5)}° E
                  </div>
                </div>
              </div>
              <a 
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-xs font-bold text-orange-600 hover:text-orange-700 hover:underline"
              >
                Maps <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="border-t-2 border-slate-200/80 pt-3.5 flex items-start gap-2.5 text-xs text-slate-500">
              <Clock className="w-4.5 h-4.5 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-800 font-display">Logged Time:</span>
                <p className="mt-0.5">
                  {new Date(report.createdAt).toLocaleString(undefined, {
                    dateStyle: "medium",
                    timeStyle: "short"
                  })}
                </p>
              </div>
            </div>

            <div className="border-t-2 border-slate-200/80 pt-3.5 flex items-start gap-2.5 text-xs text-slate-500">
              <User className="w-4.5 h-4.5 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-800 font-display">Reporter:</span>
                <p className="mt-0.5 font-mono text-[11px] truncate max-w-[180px]">
                  {report.reporterName || "Anonymous Resident"} ({report.reporterEmail || "Guest"})
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Damage Description & Dynamic Timeline */}
        <div className="p-6 md:col-span-7 space-y-6 md:border-l-2 md:border-slate-900">
          <div>
            <h3 className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-2 font-mono">
              AI Damage Assessment
            </h3>
            <div className="p-4 bg-orange-50 border-2 border-slate-900 rounded-xl shadow-[3px_3px_0px_0px_rgba(249,115,22,0.1)]">
              <p className="text-slate-850 text-sm leading-relaxed whitespace-pre-wrap font-sans">
                {report.description || "No description logged for this artifact."}
              </p>
            </div>
          </div>

          {/* Stepped Timeline */}
          <div>
            <h3 className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-4 font-mono">
              Inter-agency Progress Timeline
            </h3>

            <div className="space-y-6 relative before:absolute before:inset-y-0 before:left-[11px] before:w-[3px] before:bg-slate-200">
              {statusWorkflow.map((step, idx) => {
                const isPassed = idx < currentStatusIndex;
                const isCurrent = idx === currentStatusIndex;
                const isFuture = idx > currentStatusIndex;

                return (
                  <div key={step.value} className="relative flex gap-4 items-start pl-1">
                    {/* Circle Indicator */}
                    <div className="relative shrink-0 mt-1">
                      {isPassed && (
                        <CheckCircle2 className="w-5 h-5 text-orange-600 bg-white rounded-full z-10 relative" />
                      )}
                      {isCurrent && (
                        <Wrench className="w-5 h-5 text-orange-600 bg-white rounded-full z-10 p-0.5 border-2 border-slate-950 animate-pulse relative" />
                      )}
                      {isFuture && (
                        <div className="w-5 h-5 rounded-full border-2 border-slate-350 bg-white z-10 relative" />
                      )}
                    </div>

                    {/* Step descriptions */}
                    <div>
                      <h4 className={`text-xs font-bold leading-none uppercase tracking-wide font-display ${
                        isCurrent ? "text-slate-900 font-extrabold" : isPassed ? "text-slate-700" : "text-slate-400"
                      }`}>
                        {step.label}
                      </h4>
                      <p className={`text-[11px] mt-1.5 italic ${
                        isCurrent ? "text-slate-600 font-semibold" : "text-slate-400"
                      }`}>
                        {step.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Admin resolution block */}
          {report.adminNotes && (
            <div className="p-4 bg-slate-100 border-2 border-slate-900 rounded-xl space-y-1.5 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
              <h4 className="text-xs uppercase font-extrabold text-slate-600 font-mono flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-slate-500" />
                Official Repair Resolution Note
              </h4>
              <p className="text-slate-800 text-xs leading-relaxed font-mono">
                {report.adminNotes}
              </p>
            </div>
          )}

          {/* Sandbox Authority Panel Switch */}
          {onUpdateStatus && (
            <div className="border-t-2 border-slate-200/80 pt-4">
              <button
                id="btn-toggle-sim-panel"
                type="button"
                onClick={() => setShowSimPanel(!showSimPanel)}
                className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono flex items-center gap-1.5 bg-white border-2 border-slate-900 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] px-4 py-2 rounded-lg transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5 text-orange-500" />
                {showSimPanel ? "Hide simulation mode" : "Simulate Local Authority Update"}
              </button>

              {showSimPanel && (
                <div id="sim-control-panel" className="bg-slate-50 p-4 rounded-xl border-2 border-slate-900 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] mt-3 space-y-4 animate-fadeIn">
                  <div className="text-xs text-slate-600">
                    <span className="font-extrabold text-slate-800 font-mono">DEMONSTRATION CONTROL PANEL:</span> Bypasses official municipal authentication servers to demonstrate rapid ticketing transitions instantly.
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-black text-slate-400 mb-1.5 font-mono">
                      Official Repair Resolution Note (Demonstration Log)
                    </label>
                    <textarea
                      id="sim-admin-notes"
                      value={adminNotes}
                      onChange={(e) => setAdminNotes(e.target.value)}
                      placeholder="e.g. Dispatched tarmac patching crew. Installed 150W LED retrofit driver."
                      className="w-full text-xs p-2.5 bg-white border-2 border-slate-900 rounded-lg focus:outline-none focus:border-orange-500 font-mono"
                      rows={2}
                    />
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    {statusWorkflow.slice(1).map((step) => (
                      <button
                        key={step.value}
                        id={`btn-transition-${step.value}`}
                        onClick={() => handleStateTransition(step.value)}
                        disabled={updating || report.status === step.value}
                        type="button"
                        className={`text-[10px] px-3 py-1.5 rounded-lg border-2 font-bold tracking-wide uppercase font-mono transition-all active:scale-95 disabled:pointer-events-none disabled:opacity-50 ${
                          report.status === step.value
                            ? "bg-slate-200 text-slate-700 border-slate-350"
                            : "bg-white hover:bg-slate-100 text-slate-800 border-slate-900 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]"
                        }`}
                      >
                        {step.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
