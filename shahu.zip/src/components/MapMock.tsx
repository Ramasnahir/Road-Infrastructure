import React, { useEffect, useState } from "react";
import { MapPin, Navigation, Compass, RefreshCw, Radio } from "lucide-react";

interface MapMockProps {
  latitude: number;
  longitude: number;
  onChange: (lat: number, lng: number) => void;
}

export default function MapMock({ latitude, longitude, onChange }: MapMockProps) {
  const [gpsLoading, setGpsLoading] = useState<boolean>(false);
  const [gpsStatus, setGpsStatus] = useState<string>("Active Tracker");
  const [direction, setDirection] = useState<number>(45);

  // Auto Geolocate on load
  useEffect(() => {
    handleGeolocate();
  }, []);

  const handleGeolocate = () => {
    if (!navigator.geolocation) {
      setGpsStatus("GPS not supported by browser");
      return;
    }
    
    setGpsLoading(true);
    setGpsStatus("Acquiring GPS Signal...");
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        onChange(position.coords.latitude, position.coords.longitude);
        setGpsLoading(false);
        setGpsStatus("GPS Locked (High Accuracy)");
        // Add subtle variation to compass direction
        setDirection(Math.floor(Math.random() * 360));
      },
      (error) => {
        console.warn("Geolocation lookup rejected", error);
        setGpsLoading(false);
        setGpsStatus("Using Default Location Coordinates");
        // Maintain standard default coordinates (Bangalore center)
        onChange(12.9716, 77.5946);
      },
      { enableHighAccuracy: true, timeout: 6000 }
    );
  };

  return (
    <div id="gps-coordinate-dashboard" className="bg-slate-50 border border-slate-200/60 rounded-2xl p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="relative flex h-2.5 w-2.5">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${gpsLoading ? "bg-amber-400" : "bg-emerald-400"}`}></span>
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${gpsLoading ? "bg-amber-500" : "bg-emerald-500"}`}></span>
          </div>
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider font-mono">
            {gpsStatus}
          </span>
        </div>

        <button
          id="btn-refresh-gps"
          onClick={handleGeolocate}
          disabled={gpsLoading}
          type="button"
          className="p-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-800 transition active:scale-95 disabled:opacity-50"
          title="Recalculate Current GPS"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${gpsLoading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Styled Grid Mock Map */}
      <div className="relative h-24 bg-slate-900 rounded-xl overflow-hidden border border-slate-950 flex shadow-inner">
        {/* Map Blueprint Grid */}
        <div 
          className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#0ea5e9_1px,transparent_1px),linear-gradient(to_bottom,#0ea5e9_1px,transparent_1px)] bg-[size:12px_12px]" 
        />
        {/* Map Center Coordinates Indicator */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative">
            <div className="absolute -inset-4 bg-emerald-500/10 rounded-full animate-ping opacity-60" />
            <div className="absolute -inset-8 bg-emerald-500/5 rounded-full animate-pulse opacity-40" />
            <MapPin className="w-6 h-6 text-emerald-500 fill-emerald-500/20 drop-shadow-[0_2px_8px_rgba(16,185,129,0.4)]" />
          </div>
        </div>

        {/* HUD Overlay Stats Info */}
        <div className="absolute bottom-2 left-2 text-[10px] font-mono text-slate-400 bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded border border-slate-800">
          LAT: {latitude.toFixed(6)}
          <br />
          LNG: {longitude.toFixed(6)}
        </div>

        <div className="absolute top-2 right-2 text-[10px] font-mono text-slate-500 flex items-center gap-1">
          <Compass className="w-3 h-3 animate-pulse" style={{ transform: `rotate(${direction}deg)` }} />
          <span>RAD: 12M</span>
        </div>
      </div>

      {/* Manual Pinpoint Inputs */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1 font-mono">
            Latitude Coordinate
          </label>
          <input
            id="input-latitude"
            type="number"
            step="0.0001"
            value={latitude}
            onChange={(e) => onChange(parseFloat(e.target.value) || 0, longitude)}
            className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-mono focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
          />
        </div>
        <div>
          <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1 font-mono">
            Longitude Coordinate
          </label>
          <input
            id="input-longitude"
            type="number"
            step="0.0001"
            value={longitude}
            onChange={(e) => onChange(latitude, parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 font-mono focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
          />
        </div>
      </div>
    </div>
  );
}
