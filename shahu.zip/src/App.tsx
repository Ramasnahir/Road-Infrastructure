import React, { useState, useEffect } from "react";
import { 
  PlusCircle, Search, Building2, AlertCircle, Map, 
  UserCheck, CheckSquare, Camera, Sparkles, MapPin, 
  Activity, LogOut, Copy, Check, Loader2, Info, ChevronRight,
  User, Send, RefreshCw, AlertTriangle, ShieldAlert
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  db, auth, signInWithGoogle, logoutUser, 
  handleFirestoreError, OperationType 
} from "./lib/firebase";
import { 
  collection, doc, getDoc, getDocs, setDoc, updateDoc, 
  query, where, orderBy, onSnapshot, serverTimestamp 
} from "firebase/firestore";
import { Report, IssueType, SeverityLevel, TicketStatus, UserStats } from "./types";
import CameraCapture from "./components/CameraCapture";
import MapMock from "./components/MapMock";
import TicketDetails from "./components/TicketDetails";

export default function App() {
  // Authentication states
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [guestMode, setGuestMode] = useState<boolean>(false);
  const [guestEmail, setGuestEmail] = useState<string>("");
  const [guestName, setGuestName] = useState<string>("");

  // Navigation modes: "report" | "status" | "authority"
  const [activeTab, setActiveTab] = useState<"report" | "status" | "authority">("report");

  // Report creation states
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [issueType, setIssueType] = useState<IssueType>("pothole");
  const [severity, setSeverity] = useState<SeverityLevel>("medium");
  const [description, setDescription] = useState<string>("");
  const [latitude, setLatitude] = useState<number>(12.9716); // Default Bangalore Center Lat
  const [longitude, setLongitude] = useState<number>(77.5946); // Default Bangalore Center Lng
  const [analyzingImage, setAnalyzingImage] = useState<boolean>(false);
  const [submittingReport, setSubmittingReport] = useState<boolean>(false);
  const [createdTicketId, setCreatedTicketId] = useState<string | null>(null);

  // Status tracker lookup states
  const [searchTicketId, setSearchTicketId] = useState<string>("");
  const [searchedReport, setSearchedReport] = useState<Report | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [searching, setSearching] = useState<boolean>(false);

  // Public dashboard lists
  const [allReports, setAllReports] = useState<Report[]>([]);
  const [reportsLoading, setReportsLoading] = useState<boolean>(true);
  const [copiedTicketId, setCopiedTicketId] = useState<string | null>(null);

  // Stats Counters
  const [stats, setStats] = useState<UserStats>({ submitted: 0, resolved: 0, inProgress: 0 });

  // Monitor Auth Changes
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
      if (currentUser) {
        setGuestMode(false);
      }
    });
    return unsubscribe;
  }, []);

  // Public dashboard sync from Firestore
  useEffect(() => {
    if (authLoading) return;
    if (!user && !guestMode) return;

    setReportsLoading(true);
    const reportsCollection = collection(db, "reports");
    const q = query(reportsCollection, orderBy("createdAt", "desc"));

    // Set up standard onSnapshot sync as guided in the skill
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const reportsData: Report[] = [];
        snapshot.forEach((docSnap) => {
          reportsData.push({ id: docSnap.id, ...docSnap.data() } as Report);
        });
        setAllReports(reportsData);
        setReportsLoading(false);

        // Compute local stats metrics
        const countSubmitted = reportsData.length;
        const countResolved = reportsData.filter(r => r.status === "resolved").length;
        const countInProgress = reportsData.filter(r => r.status === "in_progress" || r.status === "scheduled").length;
        setStats({ submitted: countSubmitted, resolved: countResolved, inProgress: countInProgress });
      },
      (error) => {
        // Enforce reporting custom security permission info
        handleFirestoreError(error, OperationType.LIST, "reports");
      }
    );

    return unsubscribe;
  }, [authLoading, user, guestMode]);

  // Handle Image Analysis using server-side proxy
  const handlePhotoCaptured = async (base64Image: string) => {
    setCapturedImage(base64Image);
    setAnalyzingImage(true);
    setDescription(""); // Clear previous draft description

    try {
      const response = await fetch("/api/analyze-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: base64Image, mimeType: "image/jpeg" }),
      });

      const data = await response.json();
      if (data.error) {
        console.warn("AI Analysis returned non-fatal error:", data.error);
        if (data.fallback) {
          setIssueType(data.fallback.type);
          setSeverity(data.fallback.severity);
          setDescription(data.fallback.description);
        }
      } else {
        // Successful analysis! Auto fill attributes
        if (data.type) setIssueType(data.type);
        if (data.severity) setSeverity(data.severity);
        if (data.description) setDescription(data.description);
      }
    } catch (err) {
      console.error("AI analyzing image failed", err);
      setDescription("Roadway hazard reported at logged location. Click send to dispatch utility crew.");
    } finally {
      setAnalyzingImage(false);
    }
  };

  // Generate short unique ticket reference e.g. NR-XF521
  const generateTicketId = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // No easily confused characters
    let suffix = "";
    for (let i = 0; i < 5; i++) {
      suffix += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `NR-${suffix}`;
  };

  // Submit report to Firestore
  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!capturedImage) return;

    setSubmittingReport(true);
    const tickId = generateTicketId();
    const docId = tickId; // Write explicitly using the Ticket ID for clean reference matching!

    const reporterUid = user ? user.uid : "guest";
    const repEmail = user ? user.email || "anonymous@raste.in" : guestEmail || "guest-commuter@raste.in";
    const repName = user ? user.displayName || "Citizen" : guestName || "Guest Commuter";

    const reportPayload: Report = {
      ticketId: tickId,
      imageUrl: capturedImage,
      type: issueType,
      severity: severity,
      description: description || "No Description Provided",
      latitude: latitude,
      longitude: longitude,
      status: "submitted",
      createdAt: new Date().toISOString(), // Use simple ISO string to ensure rules validations are straightforward or format compliance
      reportedBy: reporterUid,
      reporterName: repName,
      reporterEmail: repEmail,
    };

    try {
      // Create document in reports collection under exact Ticket ID identifier inside firestore!
      const reportRef = doc(db, "reports", docId);
      
      // Since rules compare createdAt schema values, we use the literal date payload for simple rules parsing and validation
      await setDoc(reportRef, reportPayload);

      setCreatedTicketId(tickId);
      // Reset drafting variables
      setCapturedImage(null);
      setDescription("");
      
      // Auto-trigger copy support
      navigator.clipboard.writeText(tickId);
    } catch (err) {
      console.error("Failed to commit report document", err);
      handleFirestoreError(err, OperationType.CREATE, `reports/${docId}`);
    } finally {
      setSubmittingReport(false);
    }
  };

  // Update Status from Detail Panel (Simulates Administration Workflow)
  const handleUpdateTicketStatus = async (status: TicketStatus, adminNotes?: string) => {
    if (!searchedReport && !searchTicketId) return;
    const targetId = searchedReport?.ticketId || searchTicketId;

    try {
      const docRef = doc(db, "reports", targetId);
      const updatePayload: any = {
        status: status,
        updatedAt: new Date().toISOString()
      };
      if (adminNotes !== undefined) {
        updatePayload.adminNotes = adminNotes;
      }

      await updateDoc(docRef, updatePayload);
      
      // Sync local searched state details
      setSearchedReport((prev: any) => {
        if (!prev) return null;
        return { ...prev, status, adminNotes: adminNotes || prev.adminNotes };
      });
    } catch (err) {
      console.error("Authority state transition failed", err);
      handleFirestoreError(err, OperationType.UPDATE, `reports/${targetId}`);
    }
  };

  // Global administrative state update directly in Public Dashboard Lists
  const handleGlobalStatusUpdate = async (ticketId: string, status: TicketStatus, adminNotes: string) => {
    try {
      const docRef = doc(db, "reports", ticketId);
      await updateDoc(docRef, {
        status: status,
        adminNotes: adminNotes,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      console.error("Failed administrative status push", err);
      handleFirestoreError(err, OperationType.UPDATE, `reports/${ticketId}`);
    }
  };

  // Search Ticket ID manually via the Status Tracker tab
  const handleTicketSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTicketId.trim()) return;

    setSearching(true);
    setSearchError(null);
    setSearchedReport(null);

    const formattedId = searchTicketId.trim().toUpperCase();

    try {
      const docRef = doc(db, "reports", formattedId);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data() as Report;
        setSearchedReport({ id: docSnap.id, ...data });
      } else {
        setSearchError("No logged ticket matches this reference. Please check the ID (e.g. NR-xxxxx) and try again.");
      }
    } catch (err) {
      console.error("Search query failed", err);
      handleFirestoreError(err, OperationType.GET, `reports/${formattedId}`);
    } finally {
      setSearching(false);
    }
  };

  const copyToClipboard = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedTicketId(id);
    setTimeout(() => setCopiedTicketId(null), 2000);
  };

  // Pre-fill search field for fast testing
  const handlePrefillSearch = (id: string) => {
    setSearchTicketId(id);
    setActiveTab("status");
    // Trigger virtual query
    setTimeout(() => {
      const docRef = doc(db, "reports", id);
      getDoc(docRef).then((snap) => {
        if (snap.exists()) {
          setSearchedReport({ id: snap.id, ...snap.data() } as Report);
        }
      });
    }, 150);
  };

  const handleGuestLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;
    setGuestMode(true);
  };

  // Auth Screen loading state
  if (authLoading) {
    return (
      <div id="loader-view" className="fixed inset-0 bg-slate-50 flex flex-col items-center justify-center">
        <Loader2 className="w-8 h-8 text-orange-500 animate-spin mb-3" />
        <span className="text-sm font-bold text-slate-700 font-mono tracking-wide">Initializing Namma-Raste Grid...</span>
      </div>
    );
  }

  // Security Login Screen (to prevent spam)
  if (!user && !guestMode) {
    return (
      <div id="authentication-door" className="min-h-screen bg-[#F8FAFC] flex flex-col justify-center py-12 sm:px-6 lg:px-8 border-8 sm:border-[12px] border-white font-sans">
        <div className="absolute top-6 left-6 flex items-center gap-2 text-slate-900 font-black font-display tracking-wider text-base">
          <Activity className="w-5 h-5 text-orange-500 animate-pulse" />
          <span>NAMMA-RASTE</span>
        </div>

        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center px-4">
          <div className="mx-auto w-14 h-14 bg-orange-100 text-orange-600 border-2 border-slate-900 rounded-xl flex items-center justify-center mb-4 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight font-display uppercase">
            Namma-Raste Reporter
          </h2>
          <p className="mt-2 text-xs text-slate-500 max-w-xs mx-auto font-sans font-medium leading-relaxed">
            Authorized citizens reporting road hazards securely with automatic GPS geotags and instant ticketing.
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
          <div className="bg-white py-8 px-6 sm:px-10 border-2 border-slate-900 rounded-2xl shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] space-y-6">
            
            {/* Action 1: Google login */}
            <div className="space-y-3 font-sans">
              <button
                id="btn-google-login"
                onClick={signInWithGoogle}
                type="button"
                className="w-full flex items-center justify-center gap-3 px-5 py-3.5 border-2 border-slate-900 bg-white hover:bg-slate-50 hover:shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] rounded-xl text-sm font-bold text-slate-800 active:scale-98 transition-all shadow-sm cursor-pointer"
              >
                {/* Minimalist Vector Google G Shape Icon */}
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path fill="#EA4335" d="M12.24 10.285V14.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.579-7.859-8s3.53-8 7.859-8c2.46 0 4.105 1.025 5.047 1.926l3.253-3.13C18.28 1.815 15.42 1 12.24 1 5.92 1 12.24s4.92 11.24 11.24 11.24c6.6 0 11-4.64 11-11.24 0-.756-.08-1.332-.18-1.955H12.24z" />
                </svg>
                Sign in with Google
              </button>
            </div>

            <div className="relative flex items-center justify-center py-1">
              <div className="absolute inset-x-0 border-t-2 border-slate-200" />
              <span className="relative bg-white px-3 text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
                Or enter as verified Guest
              </span>
            </div>

            {/* Action 2: Guest validation */}
            <form onSubmit={handleGuestLogin} className="space-y-4">
              <div>
                <label className="block text-[10px] font-extrabold text-slate-500 mb-1.5 font-mono uppercase tracking-wider">
                  Full Citizen Name
                </label>
                <input
                  id="guest-name"
                  type="text"
                  required
                  placeholder="e.g. Anand Kumar"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border-2 border-slate-200 focus:bg-white focus:outline-none focus:border-orange-500 rounded-xl text-sm font-medium text-slate-800 transition-all font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-extrabold text-slate-500 mb-1.5 font-mono uppercase tracking-wider">
                  Email Address
                </label>
                <input
                  id="guest-email"
                  type="email"
                  placeholder="e.g. anand@namma-raste.in"
                  value={guestEmail}
                  onChange={(e) => setGuestEmail(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border-2 border-slate-200 focus:bg-white focus:outline-none focus:border-orange-500 rounded-xl text-sm font-medium text-slate-800 transition-all font-mono"
                />
              </div>

              <button
                id="btn-guest-proceed"
                type="submit"
                className="w-full flex items-center justify-center gap-2 px-5 py-3.5 border-2 border-slate-900 bg-orange-500 hover:bg-orange-600 rounded-xl text-xs uppercase tracking-wider font-bold text-white shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] hover:shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] active:scale-95 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(15,23,42,1)] transition-all cursor-pointer font-mono"
              >
                Proceed as Resident
                <ChevronRight className="w-4 h-4" />
              </button>
            </form>

            <div className="text-[11px] text-center text-slate-400 font-medium leading-normal">
              By accessing Namma-Raste infrastructure networks, citizens help prevent accidents. Reports are dispatched immediately to regional ward crews.
            </div>

          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] border-8 sm:border-[12px] border-white p-4 sm:p-8 space-y-8 font-sans text-slate-900 selection:bg-orange-500 selection:text-white">
      
      {/* Dynamic Header */}
      <header className="bg-white border-2 border-slate-900 p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 rounded-2xl shadow-[6px_6px_0px_0px_rgba(15,23,42,1)]">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-orange-500 text-white border-2 border-slate-900 rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
            <Activity className="w-6 h-6 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 font-mono text-[10px] text-orange-600 font-extrabold uppercase tracking-widest leading-none mb-1">
              <span>Rapid Response System</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 leading-none font-display uppercase tracking-tight">
              Namma-Raste Reporter
            </h1>
          </div>
        </div>

        {/* User Badge stats details */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="hidden sm:flex items-center gap-5 bg-orange-50/50 px-4 py-2.5 rounded-xl border-2 border-slate-900 text-xs font-mono font-bold text-slate-800 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
            <div>
              <span className="text-[9px] block uppercase text-slate-550 font-black shrink-0 font-sans">Reports Logged</span>
              <span className="font-bold text-slate-900 text-sm leading-none">{stats.submitted}</span>
            </div>
            <div className="border-l-2 border-slate-900 self-stretch" />
            <div>
              <span className="text-[9px] block uppercase text-slate-550 font-black shrink-0 font-sans">In Progress</span>
              <span className="font-bold text-slate-900 text-sm leading-none">{stats.inProgress}</span>
            </div>
            <div className="border-l-2 border-slate-900 self-stretch" />
            <div>
              <span className="text-[9px] block uppercase text-slate-550 font-black shrink-0 font-sans">Resolved</span>
              <span className="font-bold text-orange-600 text-sm leading-none">{stats.resolved}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-950 text-white border-2 border-slate-900 rounded-xl px-4 py-2.5 shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
            <User className="w-4 h-4 text-orange-400 shrink-0" />
            <div className="text-left font-sans mr-2">
              <div className="text-[9px] text-slate-400 font-mono tracking-wider font-bold leading-none mb-0.5">
                {guestMode ? "Verified Citizen" : "Google Account"}
              </div>
              <div className="text-xs font-bold font-mono tracking-tight leading-none text-white max-w-[120px] truncate">
                {user ? user.displayName || user.email : guestName}
              </div>
            </div>
            <button
              id="btn-logout"
              onClick={() => {
                logoutUser();
                setGuestMode(false);
                setGuestEmail("");
                setGuestName("");
              }}
              title="Sign Out"
              type="button"
              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Tabs Switch Section */}
      <div className="flex gap-2.5 p-1.5 bg-white border-2 border-slate-900 rounded-2xl self-start max-w-sm w-full md:w-auto shadow-[4px_4px_0px_0px_rgba(15,23,42,1)]">
        <button
          id="tab-report"
          onClick={() => { setActiveTab("report"); setCreatedTicketId(null); }}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer font-mono ${
            activeTab === "report" ? "bg-orange-500 text-white border-2 border-slate-900 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]" : "text-slate-650 hover:text-slate-850 hover:bg-slate-100 border-2 border-transparent"
          }`}
        >
          <Camera className="w-3.5 h-3.5" />
          File Report
        </button>

        <button
          id="tab-status"
          onClick={() => { setActiveTab("status"); }}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer font-mono ${
            activeTab === "status" ? "bg-orange-500 text-white border-2 border-slate-900 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]" : "text-slate-650 hover:text-slate-850 hover:bg-slate-100 border-2 border-transparent"
          }`}
        >
          <Search className="w-3.5 h-3.5" />
          Track ID
        </button>

        <button
          id="tab-authority"
          onClick={() => { setActiveTab("authority"); }}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer font-mono ${
            activeTab === "authority" ? "bg-orange-500 text-white border-2 border-slate-900 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]" : "text-slate-650 hover:text-slate-850 hover:bg-slate-100 border-2 border-transparent"
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          Council Hub
        </button>
      </div>

      {/* Primary Workspace */}
      <main className="w-full">
        <AnimatePresence mode="wait">
          {/* File Report Canvas Tab */}
          {activeTab === "report" && (
            <motion.div
              key="report-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
            >
              {/* Report submission drafting form */}
              <div className="lg:col-span-7 bg-white border-2 border-slate-900 rounded-2xl shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] p-6 space-y-6">
                <div>
                  <h2 className="text-xl font-black text-slate-900 flex items-center gap-2 font-display uppercase tracking-tight">
                    <PlusCircle className="w-5 h-5 text-orange-500" />
                    Submit Rapid Infrastructure Ticket
                  </h2>
                  <p className="text-xs text-slate-500 mt-1 font-sans font-medium leading-relaxed">
                    Your real-time camera snapshot triggers our Gemini AI processor to automatically categorize the issue, estimate physical severity levels, and draft descriptive logs.
                  </p>
                </div>

                {!createdTicketId ? (
                  <form onSubmit={handleSubmitReport} className="space-y-6">
                    {/* Capture Snap Widget */}
                    <div className="space-y-2">
                      <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider font-mono">
                        1. Capture Incident Photograph
                      </label>
                      
                      {!capturedImage ? (
                        <CameraCapture onPhotoSource={handlePhotoCaptured} />
                      ) : (
                        <div id="draft-photo-preview" className="relative rounded-xl overflow-hidden aspect-video border-2 border-slate-900 shadow-inner group">
                          <img 
                            src={capturedImage} 
                            alt="Incident snapshot draft" 
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-x-0 bottom-0 bg-slate-950/80 p-3 flex items-center justify-between border-t-2 border-slate-900">
                            <span className="text-[10px] text-white font-mono font-bold uppercase tracking-wider">Draft Snap Attached</span>
                            <button
                              id="btn-re-capture"
                              type="button"
                              onClick={() => setCapturedImage(null)}
                              className="px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white text-[10px] font-black tracking-wide uppercase rounded-lg border-2 border-slate-900 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none transition cursor-pointer"
                            >
                              Retake Photograph
                            </button>
                          </div>
                          
                          {analyzingImage && (
                            <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center">
                              <Sparkles className="w-8 h-8 text-orange-400 animate-spin mb-3" />
                              <h3 className="text-sm font-black text-white uppercase tracking-wider font-display">Gemini AI Damage Assessment</h3>
                              <p className="text-[11px] text-slate-300 mt-1 max-w-xs leading-normal font-mono animate-pulse">
                                Analyzing pixel contours to infer severity grading, utility category, & repair context...
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Geolocation logger */}
                    <div className="space-y-2">
                      <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider font-mono">
                        2. Automatic GPS Geotag
                      </label>
                      <div className="border-2 border-slate-900 rounded-xl overflow-hidden shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
                        <MapMock 
                          latitude={latitude} 
                          longitude={longitude} 
                          onChange={(lat, lng) => { setLatitude(lat); setLongitude(lng); }} 
                        />
                      </div>
                    </div>

                    {/* Extracted/Refined attributes */}
                    <div className="bg-orange-50/40 rounded-xl p-5 border-2 border-slate-900 space-y-4 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)]">
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-600 font-extrabold uppercase tracking-widest font-mono">
                        <Sparkles className="w-3.5 h-3.5 text-orange-500 animate-pulse" />
                        AI Refined Attributes
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Type Selection */}
                        <div>
                          <label className="block text-[10px] font-extrabold text-slate-650 mb-1.5 font-mono uppercase tracking-wider">
                            Infrastructure Element
                          </label>
                          <select
                            id="select-pothole-light"
                            value={issueType}
                            onChange={(e) => setIssueType(e.target.value as IssueType)}
                            className="w-full text-xs p-2.5 bg-white border-2 border-slate-905 rounded-lg focus:outline-none focus:border-orange-500 font-bold font-mono text-slate-800"
                          >
                            <option value="pothole">⛔ Pavement/Pothole Damage</option>
                            <option value="streetlight">💡 Broken Streetlight</option>
                            <option value="other">⚠️ Other (Obstruction / Drain)</option>
                          </select>
                        </div>

                        {/* Severity Selection */}
                        <div>
                          <label className="block text-[10px] font-extrabold text-slate-650 mb-1.5 font-mono uppercase tracking-wider">
                            Assessed Severity Level
                          </label>
                          <select
                            id="select-severity"
                            value={severity}
                            onChange={(e) => setSeverity(e.target.value as SeverityLevel)}
                            className="w-full text-xs p-2.5 bg-white border-2 border-slate-905 rounded-lg focus:outline-none focus:border-orange-500 font-bold font-mono text-slate-800"
                          >
                            <option value="low">⚙️ Low (Minor Repair)</option>
                            <option value="medium">🟠 Medium (Accident Threat)</option>
                            <option value="high">🚨 High (Collision Risk)</option>
                            <option value="critical">☠️ Critical (Fatal Hazard)</option>
                          </select>
                        </div>
                      </div>

                      {/* Damage description logs */}
                      <div>
                        <label className="block text-[10px] font-extrabold text-slate-650 mb-1.5 font-mono uppercase tracking-wider">
                          Damage Log Description (Verified by Gemini)
                        </label>
                        <textarea
                          id="textarea-description"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          placeholder="Gemini automatically generates this text upon capturing photo. You can refine or verify here."
                          className="w-full text-xs p-3 bg-white border-2 border-slate-905 focus:outline-none focus:border-orange-500 rounded-xl leading-relaxed font-mono font-medium text-slate-800"
                          rows={3}
                          required
                        />
                      </div>
                    </div>

                    {/* Submit ticket */}
                    <button
                      id="btn-submit-ticket"
                      type="submit"
                      disabled={submittingReport || !capturedImage || analyzingImage}
                      className="w-full py-4 bg-orange-500 hover:bg-orange-600 disabled:bg-slate-300 disabled:opacity-50 text-white border-2 border-slate-900 hover:shadow-[5px_5px_0px_0px_rgba(15,23,42,1)] rounded-xl shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(15,23,42,1)] transition-all flex items-center justify-center gap-2 text-xs uppercase tracking-widest font-black font-mono cursor-pointer"
                    >
                      {submittingReport ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Logging Ticket on Network...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          Report Incident Now (One-Click)
                        </>
                      )}
                    </button>
                  </form>
                ) : (
                  /* Form Ticket Receipt Block */
                  <div id="ticket-receipt" className="border-t border-slate-100 pt-6 text-center space-y-6">
                    <div className="w-14 h-14 bg-emerald-50 border border-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                      <Check className="w-8 h-8 animate-scaleUp" />
                    </div>

                    <div>
                      <h3 className="text-xl font-black text-slate-900 leading-none">Ticket Lodged Successfully</h3>
                      <p className="text-xs text-slate-500 mt-2 max-w-sm mx-auto">
                        Your municipal hazard ticket has been assigned a unique reference. Copy this ID to track agency progress live!
                      </p>
                    </div>

                    <div className="p-4 bg-slate-900 border border-slate-950 rounded-2xl max-w-sm mx-auto select-all relative group shadow-lg">
                      <div className="text-[10px] uppercase font-bold text-slate-500 font-mono tracking-wider mb-1">
                        Track Ticket Reference ID
                      </div>
                      <div className="text-2xl font-black font-mono tracking-widest text-emerald-400">
                        {createdTicketId}
                      </div>
                      <button
                        id="btn-copy-receipt"
                        type="button"
                        onClick={() => copyToClipboard(createdTicketId)}
                        className="absolute right-3 top-3.5 p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded transition"
                      >
                        {copiedTicketId === createdTicketId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 pt-3 justify-center">
                      <button
                        id="btn-track-instant"
                        onClick={() => handlePrefillSearch(createdTicketId)}
                        className="px-5 py-2.5 bg-slate-950 text-white font-semibold rounded-xl text-xs uppercase tracking-wider shadow active:scale-95 transition"
                      >
                        Track Ticket Status
                      </button>
                      <button
                        id="btn-reset-form"
                        onClick={() => { setCreatedTicketId(null); setCapturedImage(null); }}
                        className="px-5 py-2.5 bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-950 rounded-xl text-xs uppercase tracking-wider font-semibold active:scale-95 transition"
                      >
                        Report Another Incident
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Public active incidents list */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-white border-2 border-slate-900 rounded-2xl shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black text-slate-900 flex items-center gap-2 uppercase tracking-tight font-display">
                      <Map className="w-5 h-5 text-orange-500" />
                      Public Incident Grid
                    </h3>
                    <span className="px-2.5 py-1 bg-orange-50 border-2 border-slate-900 rounded-full font-mono text-[9px] font-black text-slate-800">
                      {allReports.length} reported cases
                    </span>
                  </div>

                  {reportsLoading ? (
                    <div id="list-reports-loader" className="py-12 flex flex-col items-center text-center">
                      <Loader2 className="w-6 h-6 animate-spin text-orange-500" />
                      <span className="text-[11px] text-slate-650 font-mono mt-1 font-bold">Syncing grid logs...</span>
                    </div>
                  ) : allReports.length === 0 ? (
                    <div className="py-12 flex flex-col items-center justify-center p-4 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                      <Info className="w-6 h-6 text-slate-350 mb-2" />
                      <h4 className="text-xs font-bold text-slate-700">No active reports found</h4>
                      <p className="text-[10px] text-slate-400 mt-1 max-w-[180px]">Be the first to report local potholes or broken fixtures above.</p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
                      {allReports.map((report) => {
                        const styleConfig = {
                          pothole: "🚗 Pavement Damage",
                          streetlight: "💡 Streetlight Out",
                          other: "⚠️ Road Obstructions"
                        };
                        const levelConfig = {
                          low: "text-slate-700 bg-slate-100 border border-slate-905 font-bold font-mono px-1.5 py-0.5 text-[8px] uppercase tracking-wide",
                          medium: "text-amber-800 bg-amber-100 border border-amber-600 font-bold font-mono px-1.5 py-0.5 text-[8px] uppercase tracking-wide",
                          high: "text-orange-850 bg-orange-100 border border-orange-600 font-extrabold font-mono px-1.5 py-0.5 text-[8px] uppercase tracking-wide",
                          critical: "text-rose-850 bg-rose-100 border border-red-600 font-black font-mono px-1.5 py-0.5 text-[8px] uppercase tracking-widest animate-pulse"
                        };

                        return (
                          <div 
                            key={report.ticketId}
                            onClick={() => handlePrefillSearch(report.ticketId)}
                            className="p-3 bg-white border-2 border-slate-900 rounded-xl cursor-pointer hover:bg-orange-50/50 hover:shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] hover:-translate-x-[2px] hover:-translate-y-[2px] shadow-[1px_1px_0px_0px_rgba(15,23,42,1)] transition-all flex gap-3.5 items-start"
                          >
                            <img 
                              src={report.imageUrl} 
                              alt="Log thumb" 
                              className="w-12 h-12 rounded-lg object-cover shrink-0 border-2 border-slate-900 bg-slate-250"
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-mono text-xs font-black text-slate-900 tracking-wide block">
                                  {report.ticketId}
                                </span>
                                <span className={`shrink-0 rounded ${levelConfig[report.severity] || levelConfig.medium}`}>
                                  {report.severity}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-500 font-mono font-bold mt-1">
                                {styleConfig[report.type] || report.type} • {new Date(report.createdAt).toLocaleDateString(undefined, {month: "short", day: "numeric"})}
                              </p>
                              <p className="text-[11px] text-slate-750 line-clamp-1 mt-1 font-sans font-medium">
                                {report.description}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* Ticket ID Status tracker Tab */}
          {activeTab === "status" && (
            <motion.div
              key="status-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="max-w-3xl mx-auto space-y-6"
            >
              <div className="bg-white border-2 border-slate-900 rounded-2xl shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] p-6 space-y-6">
                <div>
                  <h2 className="text-xl font-black text-slate-900 flex items-center gap-2 font-display uppercase tracking-tight">
                    <Search className="w-5 h-5 text-orange-500" />
                    Rapid Ticket Finder
                  </h2>
                  <p className="text-xs text-slate-500 mt-1 font-sans font-medium leading-relaxed">
                    Enter the unique 8-character Ticket ID (e.g. NR-xxxxx) printed on your receipt to view real-time inter-agency dispatches and repair resolutions.
                  </p>
                </div>

                <form onSubmit={handleTicketSearch} className="flex flex-col sm:flex-row gap-3">
                  <input
                    id="search-ticket-id"
                    type="text"
                    required
                    placeholder="e.g. NR-XF521"
                    value={searchTicketId}
                    onChange={(e) => setSearchTicketId(e.target.value)}
                    className="flex-1 px-4 py-3 bg-white border-2 border-slate-900 focus:outline-none focus:border-orange-500 rounded-xl text-sm font-bold font-mono tracking-widest uppercase transition text-slate-800 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]"
                  />
                  <button
                    id="btn-search-trigger"
                    type="submit"
                    disabled={searching || !searchTicketId.trim()}
                    className="px-6 py-3 bg-orange-500 border-2 border-slate-900 hover:bg-orange-600 text-white font-bold rounded-xl shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] disabled:opacity-50 transition-all text-xs uppercase tracking-widest flex items-center justify-center gap-2 font-mono shrink-0 cursor-pointer"
                  >
                    {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    Locate Ticket
                  </button>
                </form>

                {searchError && (
                  <div className="p-4 bg-rose-50 border-2 border-red-500 rounded-xl flex items-start gap-3.5 text-xs text-rose-800 font-mono shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]">
                    <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold uppercase tracking-wider text-[10px]">Locator Failed</p>
                      <p className="mt-1 leading-relaxed font-sans">{searchError}</p>
                    </div>
                  </div>
                )}

                {/* Pre fill testing options if they don't have target */}
                {!searchedReport && !searchError && allReports.length > 0 && (
                  <div className="bg-orange-50/50 p-4 rounded-xl border-2 border-slate-900 text-xs shadow-[3px_3px_0px_0px_rgba(15,23,42,1)]">
                    <span className="font-black text-slate-700 block mb-2.5 font-mono uppercase tracking-wider text-[10px]">Quick Sandbox Select:</span>
                    <div className="flex flex-wrap gap-2">
                      {allReports.slice(0, 3).map(rep => (
                        <button
                          key={rep.ticketId}
                          type="button"
                          onClick={() => handlePrefillSearch(rep.ticketId)}
                          className="px-3 py-2 bg-white border-2 border-slate-900 rounded-lg hover:bg-orange-100 font-mono text-slate-800 font-bold active:translate-x-[1px] active:translate-y-[1px] active:shadow-none transition-all flex items-center gap-1.5 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] cursor-pointer text-[11px]"
                        >
                          <Activity className="w-3.5 h-3.5 text-orange-500" />
                          {rep.ticketId} ({rep.type})
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {searchedReport && (
                <TicketDetails 
                  report={searchedReport} 
                  onUpdateStatus={handleUpdateTicketStatus}
                />
              )}
            </motion.div>
          )}

          {/* Municipal Council Hub Tab */}
          {activeTab === "authority" && (
            <motion.div
              key="authority-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="bg-white border-2 border-slate-900 rounded-2xl shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] overflow-hidden"
            >
              {/* Town council banner */}
              <div className="p-6 bg-slate-950 text-white flex flex-col md:flex-row md:items-center justify-between gap-4 border-b-2 border-slate-900">
                <div>
                  <h2 className="text-xl font-black flex items-center gap-2 font-display uppercase tracking-tight">
                    <Building2 className="w-5 h-5 text-orange-400" />
                    Municipal Dispatch & Clearance Hub
                  </h2>
                  <p className="text-xs text-slate-400 mt-1 max-w-xl font-sans font-medium">
                    This administrative interface represents the authority view. Reviewers can approve, schedule, assign, or mark reported incidents as resolved to observe the rapid status tracker workflows.
                  </p>
                </div>
              </div>

              {/* Grid List of reports */}
              <div className="p-6">
                {reportsLoading ? (
                  <div className="py-24 flex flex-col items-center">
                    <Loader2 className="w-8 h-8 animate-spin text-orange-500 mb-2" />
                    <span className="text-xs font-mono font-bold text-slate-650">Consolidating active ward logs...</span>
                  </div>
                ) : allReports.length === 0 ? (
                  <div className="py-24 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-orange-50/20">
                    <Building2 className="w-12 h-12 text-orange-400 mx-auto mb-3" />
                    <h3 className="text-sm font-black text-slate-700 font-display uppercase">No Citizen Tickets Logged</h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto font-sans font-medium">Logged tickets submitted on the "File Report" screen populate here automatically for inter-agency coordination.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto border-2 border-slate-900 rounded-xl shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] bg-white">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-b-2 border-slate-900 text-slate-700 font-mono uppercase tracking-wider text-[10px] font-black">
                          <th className="p-4">Ticket Reference</th>
                          <th className="p-4">Incident Category</th>
                          <th className="p-4">Severity level</th>
                          <th className="p-4">Geotag Coordinates</th>
                          <th className="p-4 text-center">Status Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y-2 divide-slate-150 text-slate-700">
                        {allReports.map((report) => {
                          const statusColors: Record<TicketStatus, string> = {
                            submitted: "bg-blue-50 text-blue-900 border-blue-500",
                            in_review: "bg-purple-50 text-purple-900 border-purple-500",
                            scheduled: "bg-amber-50 text-amber-900 border-amber-500",
                            in_progress: "bg-cyan-50 text-cyan-900 border-cyan-500",
                            resolved: "bg-orange-50 text-orange-900 border-orange-500 font-black"
                          };

                          return (
                            <tr key={report.ticketId} className="hover:bg-slate-50/70 transition-colors">
                              <td className="p-4 font-mono font-black text-slate-900">
                                {report.ticketId}
                              </td>
                              <td className="p-4">
                                <div className="flex items-center gap-3">
                                  <img 
                                    src={report.imageUrl} 
                                    alt="Visual key" 
                                    className="w-10 h-10 rounded-lg object-cover bg-slate-200 border-2 border-slate-900 shrink-0"
                                    referrerPolicy="no-referrer"
                                  />
                                  <div>
                                    <span className="font-extrabold block text-slate-800 uppercase tracking-wide text-[10px] font-mono">
                                      {report.type}
                                    </span>
                                    <p className="text-[11px] text-slate-450 font-sans font-medium line-clamp-1 max-w-[200px]">
                                      {report.description}
                                    </p>
                                  </div>
                                </div>
                              </td>
                              <td className="p-4 uppercase font-bold text-[10px] tracking-wide font-mono text-slate-700">
                                {report.severity}
                              </td>
                              <td className="p-4 font-mono text-[11px] text-slate-600 font-bold">
                                {report.latitude.toFixed(4)}, {report.longitude.toFixed(4)}
                              </td>
                              <td className="p-4">
                                <div className="flex items-center justify-center gap-2">
                                  <select
                                    id={`select-status-${report.ticketId}`}
                                    value={report.status}
                                    onChange={(e) => handleGlobalStatusUpdate(report.ticketId, e.target.value as TicketStatus, report.adminNotes || "State transitioned via Municipal Clearance Dashboard.")}
                                    className={`text-[10.5px] font-black p-1.5 border-2 rounded-lg focus:outline-none uppercase tracking-wide transition cursor-pointer ${statusColors[report.status]}`}
                                  >
                                    <option value="submitted">Logged</option>
                                    <option value="in_review">Analyzing</option>
                                    <option value="scheduled">Scheduled</option>
                                    <option value="in_progress">Dispatched</option>
                                    <option value="resolved">Resolved</option>
                                  </select>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

    </div>
  );
}
